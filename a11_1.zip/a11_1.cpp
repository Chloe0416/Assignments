#include <iostream>
#include "fraction.h"
using namespace cs_fraction;


int main() {

	cout << "enter a fraction: ";
	Fraction f1;
	cin >> f1;
	cout << f1 << endl;

	system("pause");
	return 0;
}